using Microsoft.EntityFrameworkCore;
using BackEnd.Models;
using BackEnd.Data;
using BackEnd.Controllers;

namespace BackEnd.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Treino> Treinos { get; set; }
        public DbSet<Exercicio> Exercicios { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Treino>()
                .HasOne(t => t.Usuario)
                .WithMany(u => u.Treinos)
                .HasForeignKey(t => t.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<Exercicio>()
                .HasOne(e => e.Treino)
                .WithMany(t => t.Exercicios)
                .HasForeignKey(e => e.TreinoId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
