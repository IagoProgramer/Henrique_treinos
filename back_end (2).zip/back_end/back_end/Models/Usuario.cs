using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BackEnd.Models;

public class Usuario
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Email { get; set; }
    public string Senha { get; set; }

    public List<Treino> Treinos { get; set; } // Relacionamento de 1:N com Treino
    public List<Exercicio> Exercicios { get; set; } // Relacionamento de 1:N com Exercicio
}


