using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BackEnd.Models;

namespace BackEnd.Models
{
public class Exercicio
{
    public int Id { get; set; }
    public string Nome { get; set; }
    public string Descricao { get; set; }

    // Relacionamento com Treino
    public int TreinoId { get; set; }   // ID do Treino associado
    public Treino Treino { get; set; }   // Objeto Treino relacionado
    public List<Exercicio> Exercicios { get; set; }

    public int UsuarioId { get; set; }  // Chave estrangeira para Usuário

    // Defina o relacionamento com a classe Usuario
    public Usuario Usuario { get; set; }  // Relacionamento com Usuário
}

}
