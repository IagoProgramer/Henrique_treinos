using Microsoft.AspNetCore.Mvc;
using BackEnd.Models;
using BackEnd.Data;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace BackEnd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExercicioController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ExercicioController(AppDbContext context)
        {
            _context = context;
        }

        // POST: api/exercicio
        [HttpPost]
        public async Task<ActionResult<Exercicio>> CreateExercicio([FromBody] Exercicio exercicio)
        {
            _context.Exercicios.Add(exercicio);
            await _context.SaveChangesAsync();

            return CreatedAtAction(nameof(GetExercicio), new { id = exercicio.Id }, exercicio);
        }

        // GET: api/exercicio/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Exercicio>> GetExercicio(int id)
        {
            var exercicio = await _context.Exercicios.FindAsync(id);

            if (exercicio == null)
            {
                return NotFound();
            }

            return exercicio;
        }

        // GET: api/exercicio/usuario/5
        [HttpGet("usuario/{usuarioId}")]
        public async Task<ActionResult> GetExerciciosByUsuario(int usuarioId)
        {
            var exercicios = await _context.Exercicios.Where(e => e.UsuarioId == usuarioId).ToListAsync();
            return Ok(exercicios);
        }

        // PUT: api/exercicio/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateExercicio(int id, [FromBody] Exercicio exercicio)
        {
            if (id != exercicio.Id)
            {
                return BadRequest();
            }

            _context.Entry(exercicio).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ExercicioExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/exercicio/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteExercicio(int id)
        {
            var exercicio = await _context.Exercicios.FindAsync(id);
            if (exercicio == null)
            {
                return NotFound();
            }

            _context.Exercicios.Remove(exercicio);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool ExercicioExists(int id)
        {
            return _context.Exercicios.Any(e => e.Id == id);
        }
    }
}
