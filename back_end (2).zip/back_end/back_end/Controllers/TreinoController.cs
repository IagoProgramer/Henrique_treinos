using Microsoft.AspNetCore.Mvc;
using BackEnd.Models;
using BackEnd.Data;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace BackEnd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TreinoController : ControllerBase
    {
        private readonly AppDbContext _context;

        public TreinoController(AppDbContext context)
        {
            _context = context;
        }

        // POST: api/treino
        [HttpPost]
        public async Task<ActionResult<Treino>> CreateTreino([FromBody] Treino treino)
        {
            // Verificando se o treino enviado não é nulo e tem um nome
            if (treino == null || string.IsNullOrEmpty(treino.Nome))
            {
                return BadRequest("O treino deve ter um nome válido.");
            }

            // Adicionando o treino ao banco de dados
            _context.Treinos.Add(treino);
            await _context.SaveChangesAsync();

            // Retornando o treino recém criado
            return CreatedAtAction(nameof(GetTreino), new { id = treino.Id }, treino);
        }

        // GET: api/treino/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Treino>> GetTreino(int id)
        {
            var treino = await _context.Treinos.FindAsync(id);

            if (treino == null)
            {
                return NotFound();
            }

            return treino;
        }

        // GET: api/treino/usuario/5
        [HttpGet("usuario/{usuarioId}")]
        public async Task<ActionResult> GetTreinosByUsuario(int usuarioId)
        {
            // Buscando os treinos do usuário com base no ID
            var treinos = await _context.Treinos.Where(t => t.UsuarioId == usuarioId).ToListAsync();
            if (treinos == null || !treinos.Any())
            {
                return NotFound("Nenhum treino encontrado para este usuário.");
            }
            return Ok(treinos);
        }

        // PUT: api/treino/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTreino(int id, [FromBody] Treino treino)
        {
            if (id != treino.Id)
            {
                return BadRequest("O ID do treino não corresponde ao ID fornecido.");
            }

            _context.Entry(treino).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TreinoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // DELETE: api/treino/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTreino(int id)
        {
            var treino = await _context.Treinos.FindAsync(id);
            if (treino == null)
            {
                return NotFound();
            }

            _context.Treinos.Remove(treino);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TreinoExists(int id)
        {
            return _context.Treinos.Any(t => t.Id == id);
        }
    }
}
